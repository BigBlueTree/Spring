package com.study.springboot.service;

public interface IDepositService {
	public int deposit(String accountid,int money,String error);
}
