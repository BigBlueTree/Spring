package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P21TransactionManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(P21TransactionManagerApplication.class, args);
	}

}
