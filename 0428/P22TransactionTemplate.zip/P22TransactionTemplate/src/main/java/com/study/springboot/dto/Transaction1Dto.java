package com.study.springboot.dto;

import lombok.Data;

@Data
public class Transaction1Dto {
	private String accountid;
	private int amount;
}
