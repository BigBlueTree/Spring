package com.study.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P19SecurityDBApplicationTests {

	@Test
	void contextLoads() {
	}

}
