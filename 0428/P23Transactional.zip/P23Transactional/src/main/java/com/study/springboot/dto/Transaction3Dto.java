package com.study.springboot.dto;

import lombok.Data;

@Data
public class Transaction3Dto {
	private String accountid;
	private int amount;
}
