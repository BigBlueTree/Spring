package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P25LocalJarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(P25LocalJarsApplication.class, args);
	}

}
