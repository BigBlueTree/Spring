package com.study.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P17SecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
