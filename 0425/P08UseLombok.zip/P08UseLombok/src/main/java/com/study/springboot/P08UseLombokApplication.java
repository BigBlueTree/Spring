package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P08UseLombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(P08UseLombokApplication.class, args);
	}

}
