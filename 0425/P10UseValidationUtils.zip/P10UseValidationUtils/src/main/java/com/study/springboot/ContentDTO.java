package com.study.springboot;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContentDTO {
	private int id;
	private String writer;
	private String content;
}
