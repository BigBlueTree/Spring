package com.study.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P03AnnotationDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
