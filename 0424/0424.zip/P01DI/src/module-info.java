/**
 * 
 */
/**
 * @author Kosmo
 *
 */
module P01DI {
}