package com.study.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P04BasicWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
